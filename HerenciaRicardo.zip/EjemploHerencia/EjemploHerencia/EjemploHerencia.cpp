#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "Triangulo.h"

using namespace std;

int main(void) {
	Rectangulo Rect;
	Triangulo Tri;
	Triangulo *Emanuel=new Triangulo();
	int base, altura;
	cout << "Ingrese base " << endl;
	cin >> base;
	cout << "Ingrese altura " << endl;
	cin >> altura;
	Rect.setWidth(base);
	Rect.setHeight(altura);
	Tri.setWidth(base);
	Tri.setHeight(altura);
	Emanuel->setHeight(25);
	Emanuel->setWidth(10);
	// Muestra el �rea de un rectangulo
	cout << "Total area rectangulo : " << Rect.getArea() << endl;
	cout << "Total area triangulo : " << Tri.getArea() << endl;
	cout << "Total area Emanuel : " << Emanuel->getArea() << endl;
	return 0;
}